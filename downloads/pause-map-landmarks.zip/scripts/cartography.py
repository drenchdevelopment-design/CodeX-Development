"""Phone-map-inspired colors and original, procedural landmark illustrations.
Every spatial operation is at native tile resolution. No map re-projection.
"""
from pathlib import Path
import math
import cv2
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
ROOT=Path(__file__).resolve().parents[1]
FONT=str(ROOT/'source/fonts/DejaVuSans.ttf');BOLD=str(ROOT/'source/fonts/DejaVuSans-Bold.ttf')
OLD_LABELS={
 'minimap_0_0':[(1926,1826,2330,1922),(2502,2022,2900,2132),(1770,2304,2162,2400),(2556,2672,2950,2768)],
 'minimap_0_1':[(54,551,189,615),(165,845,360,904)],
 'minimap_1_0':[(1658,96,2078,180)],'minimap_1_1':[(360,94,774,202)]}

def remove_old_titles(rgb,tile):
    """Cover baked titles with quiet label halos, without inventing hidden streets.
    Only the old title footprints and their small feathered margins are covered.
    """
    result=rgb.copy()
    for x0,y0,x1,y1 in OLD_LABELS.get(tile,[]):
        feather=12 if rgb.shape[0]>1024 else 4
        left=max(0,x0-feather*3);top=max(0,y0-feather*3)
        right=min(rgb.shape[1],x1+feather*3);bottom=min(rgb.shape[0],y1+feather*3)
        mask=Image.new('L',(right-left,bottom-top))
        ImageDraw.Draw(mask).rectangle((x0-left-feather,y0-top-feather,x1-left+feather,y1-top+feather),fill=255)
        mask=mask.filter(ImageFilter.GaussianBlur(feather/2))
        amount=np.asarray(mask,dtype=float)/255
        amount[y0-top:y1-top,x0-left:x1-left]=1
        patch=result[top:bottom,left:right].astype(float)
        result[top:bottom,left:right]=np.uint8(patch*(1-amount[:,:,None])+32*amount[:,:,None])
    return result

def park_mask(tile,size):
    im=Image.new('L',size);d=ImageDraw.Draw(im)
    if tile=='minimap_0_0':d.polygon([(2645,2158),(2840,2158),(2840,2500),(2645,2500)],fill=255)
    if tile=='minimap_1_0':d.polygon([(2378,353),(2420,308),(2470,309),(2515,359),(2573,557),(2500,622),(2416,592),(2370,461)],fill=255)
    return np.asarray(im)>0

def palette(im,tile):
    a=np.asarray(im);rgb=remove_old_titles(a[:,:,:3].copy(),tile).astype(np.float32)
    r,g,b=rgb.transpose(2,0,1);lum=rgb.mean(axis=2)
    points=[0,30,65,110,155,210,255]
    colors=np.array([[7,12,20],[24,33,48],[33,46,65],[48,65,88],[64,84,111],[86,111,145],[118,138,160]])
    out=np.stack([np.interp(lum,points,colors[:,c]) for c in range(3)],axis=-1)
    water=np.clip((b-r-5)/12,0,1)*np.clip((b-g+3)/6,0,1)
    sea=np.broadcast_to(np.array([8,15,24]),out.shape)
    out=out*(1-water[:,:,None])+sea*water[:,:,None]
    # A narrow green ribbon follows the existing land edge, on the land side.
    ground=((water<.3)&(lum>10)&(lum<105)&(a[:,:,3]>0)).astype(np.uint8)
    distance=cv2.distanceTransform(ground,cv2.DIST_L2,3)
    coast=(ground>0)&(distance<max(2,im.width/340))
    # Only ground beside water; avoid painting every city block green.
    water_neighbors=cv2.dilate((water>.7).astype(np.uint8),np.ones((max(3,int(im.width/220))|1,)*2,np.uint8))>0
    coast &=water_neighbors
    out[coast]=out[coast]*.28+np.array([23,63,57])*.72
    parks=park_mask(tile,im.size)
    t=np.clip((lum-25)/115,0,1)
    grass=np.stack([21+t*40,54+t*53,46+t*39],axis=-1)
    out[parks]=grass[parks]
    # Preserve the drawn lakes within Central Park as water, rather than white land.
    lake=parks&(lum>218)
    out[lake]=[10,22,31]
    warm=np.clip((r-b-10)/30,0,1)*np.clip((r-g-4)/22,0,1)
    out=out*(1-warm[:,:,None])+np.array([92,126,158])*warm[:,:,None]
    result=np.empty_like(a);result[:,:,:3]=np.uint8(np.clip(out,0,255));result[:,:,3]=a[:,:,3]
    result[np.max(a[:,:,:3],axis=2)<5,:3]=0
    return Image.fromarray(result)

def label(im,text,xy,size,color=(235,240,247,255),bold=True,anchor='mm',stroke=2):
    d=ImageDraw.Draw(im);font=ImageFont.truetype(BOLD if bold else FONT,size)
    d.text(xy,text,font=font,fill=color,anchor=anchor,stroke_width=stroke,stroke_fill=(12,20,32,255))

def landmark(kind):
    # Supersampled original vector miniatures; the final badge is antialiased.
    im=Image.new('RGBA',(384,410));d=ImageDraw.Draw(im)
    d.ellipse((22,20,362,360),fill=(9,16,27,160))
    d.ellipse((28,16,356,344),fill=(22,33,51,255),outline=(164,182,207,255),width=6)
    d.ellipse((38,26,346,334),outline=(64,84,111,255),width=2)
    d.polygon([(175,342),(192,371),(209,342)],fill=(164,182,207,255))
    def building(x,y,w,h,front,side,roof):
        dx=19
        d.polygon([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],fill=front)
        d.polygon([(x+w,y),(x+w+dx,y-12),(x+w+dx,y+h-12),(x+w,y+h)],fill=side)
        d.polygon([(x,y),(x+dx,y-12),(x+w+dx,y-12),(x+w,y)],fill=roof)
        for yy in range(y+12,y+h-8,19):
            for xx in range(x+7,x+w-4,13):d.rectangle((xx,yy,xx+4,yy+7),fill=(153,181,205,255))
    if kind=='times-square':
        d.polygon([(64,282),(178,242),(320,284),(205,316)],fill=(57,68,89,255))
        building(80,149,42,126,(69,83,114),(39,55,83),(118,132,153))
        building(133,81,55,202,(99,114,132),(52,70,93),(165,177,190))
        building(214,116,51,171,(63,77,106),(35,51,77),(130,148,168))
        building(277,180,30,105,(91,86,117),(51,55,89),(143,137,163))
        d.line((159,82,159,46),fill=(194,210,220),width=4)
        for box,color in [((137,123,183,163),(104,157,246)),((138,177,183,214),(204,114,232)),((217,150,260,190),(239,194,106)),((82,200,118,239),(83,213,204)),((219,205,261,251),(233,128,151))]:
            d.rectangle(box,fill=color);d.line((box[0]+5,box[1]+9,box[2]-5,box[1]+9),fill=(240,246,255),width=3)
        d.polygon([(179,284),(189,228),(207,228),(231,294),(205,305)],fill=(169,188,218))
        d.line((192,277,222,287),fill=(243,212,145),width=3)
    elif kind=='brooklyn-bridge':
        d.polygon([(61,255),(198,199),(327,258),(190,311)],fill=(27,64,86))
        for y in [265,278,291]:d.line((100,y,175,y+15),fill=(60,102,125),width=2)
        d.polygon([(63,248),(74,233),(318,190),(327,207)],fill=(163,158,147))
        d.line((69,239,323,195),fill=(227,220,199),width=5)
        # Two recognizable Gothic stone towers with paired pointed arches.
        for x,y in [(119,128),(245,107)]:
            d.polygon([(x,y),(x+46,y-8),(x+46,y+125),(x,y+134)],fill=(189,179,148))
            d.polygon([(x+46,y-8),(x+57,y-15),(x+57,y+117),(x+46,y+125)],fill=(119,119,110))
            d.polygon([(x-3,y),(x+45,y-8),(x+56,y-15),(x+9,y-8)],fill=(219,208,180))
            for off in [8,27]:
                d.polygon([(x+off,y+100),(x+off,y+33),(x+off+7,y+19),(x+off+14,y+30),(x+off+14,y+98)],fill=(28,41,54))
            d.line((x,y+13,x+46,y+5),fill=(232,218,184),width=3)
        # Suspension cables follow catenary-like curves between the towers.
        for start,end in [((75,218),(135,127)),((138,126),(265,104)),((265,104),(324,186))]:
            pts=[]
            for i in range(31):
                t=i/30;x=start[0]*(1-t)+end[0]*t;y=start[1]*(1-t)+end[1]*t+33*math.sin(math.pi*t)
                pts.append((x,y))
            d.line(pts,fill=(208,217,225),width=3)
            for x,y in pts[::4]:d.line((x,y,x,237-(x-75)*.17),fill=(140,160,180),width=1)
    elif kind=='statue-of-liberty':
        d.ellipse((80,267,302,308),fill=(29,65,59))
        d.polygon([(143,267),(154,241),(230,241),(245,275),(191,294)],fill=(162,154,135))
        d.polygon([(156,241),(166,205),(218,205),(230,241)],fill=(186,174,150))
        d.polygon([(169,204),(175,154),(185,131),(207,133),(214,163),(226,214)],fill=(93,168,146))
        d.polygon([(185,135),(199,139),(207,212),(177,211)],fill=(130,196,171))
        d.line((188,153,184,199),fill=(62,124,115),width=4)
        d.line((203,158,214,209),fill=(65,135,120),width=3)
        d.polygon([(181,140),(163,124),(154,91),(165,88),(177,116),(195,134)],fill=(127,190,164))
        d.rectangle((153,77,166,92),fill=(122,181,158))
        d.polygon([(153,77),(151,66),(158,54),(165,67),(166,77)],fill=(239,204,122))
        d.ellipse((179,106,204,136),fill=(132,194,166))
        d.arc((176,100,209,132),180,355,fill=(171,220,192),width=5)
        for x,y in [(174,98),(183,88),(194,85),(207,92),(216,101)]:d.line((192,112,x,y),fill=(157,211,183),width=4)
        d.polygon([(207,147),(223,150),(216,180),(201,175)],fill=(73,139,130))
        d.rectangle((209,146,224,174),fill=(144,197,175))
    return im

ICON_CACHE={}
def badge(im,kind,center,size,title):
    if kind not in ICON_CACHE:
        ICON_CACHE[kind]=landmark(kind)
        assets=ROOT/'source/landmarks';assets.mkdir(exist_ok=True)
        ICON_CACHE[kind].save(assets/(kind+'.png'))
    icon=ICON_CACHE[kind].resize((size,int(size*410/384)),Image.Resampling.LANCZOS)
    x,y=center;im.alpha_composite(icon,(int(x-size/2),int(y-size/2)))
    # Names remain legible but secondary to the major neighborhood labels.
    label(im,title,(x,y+size*.64),max(17,int(size*.145)),bold=False,stroke=2)

def park_pin(im,xy,title,scale=3):
    x,y=xy;d=ImageDraw.Draw(im);r=6*scale
    d.ellipse((x-r,y-r,x+r,y+r),fill=(57,119,90),outline=(103,158,120),width=scale)
    d.polygon([(x,y-4*scale),(x-3*scale,y+2*scale),(x+3*scale,y+2*scale)],fill=(15,41,31))
    d.line((x,y+2*scale,x,y+4*scale),fill=(15,41,31),width=scale)
    label(im,title,(x+10*scale,y),8*scale,color=(109,174,131,255),bold=False,anchor='lm',stroke=max(1,scale//2))

def decorate(im,tile):
    im=palette(im,tile)
    if tile=='minimap_0_0':
        label(im,'Woodbridge',(2128,1874),40)
        label(im,'Harlem',(2701,2077),60)
        label(im,'New Jersey',(1966,2352),58)
        label(im,'Manhattan',(2753,2722),54)
        park_pin(im,(2675,2290),'Central Park')
        badge(im,'times-square',(2680,2560),174,'Times Square')
    elif tile=='minimap_0_1':
        label(im,'The Bronx',(130,579),21,stroke=1)
        label(im,'Queens',(269,862),22,stroke=1)
    elif tile=='minimap_1_0':
        label(im,'East Jersey State Prison',(1865,139),29,bold=False,stroke=2)
        badge(im,'statue-of-liberty',(2462,426),196,'Statue of Liberty')
        label(im,'Liberty Island',(2480,663),31,bold=False,stroke=2)
    elif tile=='minimap_1_1':
        label(im,'Brooklyn',(567,148),61)
        badge(im,'brooklyn-bridge',(189,112),188,'Brooklyn Bridge')
    return im
