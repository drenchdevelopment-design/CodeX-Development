"""Restyle the supplied RSC7/BC3 map in place. No texture pointers are rebuilt.
Requires Python 3, numpy, opencv-python-headless, Pillow >=12 with the BCn encoder.
Usage: python scripts/build-map.py /path/to/original/mini-map
"""
from pathlib import Path
import sys,struct,zlib,io,json,hashlib,shutil
import numpy as np
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT/'source'/'mini-map'
OUT=ROOT/'mini-map';OUT.mkdir(exist_ok=True)
PREVIEW=ROOT/'previews';PREVIEW.mkdir(exist_ok=True)
FONT=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
BOLD=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf')
if (ROOT/'source/fonts/DejaVuSans.ttf').exists():
 FONT=ROOT/'source/fonts/DejaVuSans.ttf';BOLD=ROOT/'source/fonts/DejaVuSans-Bold.ttf'

def records(raw):
 assert raw[:4]==b'RSC7' and struct.unpack_from('<I',raw,8)[0]==0x20000,'Unexpected resource layout'
 data=zlib.decompress(raw[16:],-15)
 def u64(p):return struct.unpack_from('<Q',data,p)[0]
 def ptr(v):
  if v>>28==5:return v-0x50000000
  if v>>28==6:return v-0x60000000+8192
  raise ValueError(f'Unknown pointer {v:x}')
 listing=ptr(u64(0x30));count=struct.unpack_from('<H',data,0x38)[0];out=[]
 for i in range(count):
  pos=ptr(u64(listing+8*i));n=ptr(u64(pos+0x28));name=data[n:data.index(0,n)].decode()
  w,h,depth,stride,fmt=struct.unpack_from('<HHHHI',data,pos+0x50)
  out.append(dict(name=name,width=w,height=h,depth=depth,stride=stride,format=fmt,levels=data[pos+0x5d],structure=pos,pixels=ptr(u64(pos+0x70))))
 return data,out

def bc_size(w,h):return ((w+3)//4)*((h+3)//4)*16

def decode(data,record):
 w,h=record['width'],record['height'];size=bc_size(w,h)
 header=[124,0x81007,h,w,size,0,1]+[0]*11+[32,4,0x35545844,0,0,0,0,0]+[0x1000,0,0,0,0]
 return Image.open(io.BytesIO(b'DDS '+struct.pack('<31I',*header)+data[record['pixels']:record['pixels']+size])).convert('RGBA')

from cartography import decorate

def encode(im):
 b=io.BytesIO();im.save(b,format='DDS',pixel_format='DXT5');raw=b.getvalue();assert raw[:4]==b'DDS ' and raw[84:88]==b'DXT5'
 return raw[128:]

def replace_texture(data,rec,im,keep_alpha=True):
 data=bytearray(data);w,h=rec['width'],rec['height'];offset=rec['pixels'];sizes=[]
 for level in range(rec['levels']):
  size=bc_size(w,h);scaled=im if level==0 else im.resize((w,h),Image.Resampling.LANCZOS)
  packed=bytearray(encode(scaled));assert len(packed)==size
  if keep_alpha:
   # Retain the original BC3 alpha endpoints/indices EXACTLY, at every mip.
   dst=np.frombuffer(packed,dtype=np.uint8).reshape(-1,16)
   src=np.frombuffer(data[offset:offset+size],dtype=np.uint8).reshape(-1,16)
   dst[:,:8]=src[:,:8]
  data[offset:offset+size]=packed;sizes.append((offset,size));offset+=size;w=max(1,w//2);h=max(1,h//2)
 return bytes(data),sizes

def pack(header,data):
 compress=zlib.compressobj(9,zlib.DEFLATED,-15)
 return header+compress.compress(data)+compress.flush()

# Copy the original resource only, never the unrelated HUD from the earlier task.
for p in SOURCE.rglob('*'):
 if p.is_file() and p.name!='__resource.lua':
  out=OUT/p.relative_to(SOURCE);out.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,out)
(OUT/'fxmanifest.lua').write_text("fx_version 'cerulean'\ngame 'gta5'\nauthor 'City map texture update'\ndescription 'Modern pause-map artwork; original city geometry'\nversion '4.0.0'\n")
report=[];base_images={};old_images={}
for path in sorted((SOURCE/'stream').glob('*.ytd')):
 if path.name == 'minimap.ytd':continue
 raw=path.read_bytes();data,recs=records(raw);assert len(recs)==1
 rec=recs[0];assert rec['format']==0x35545844
 tile=path.stem.replace('minimap_sea_','minimap_');old=decode(data,rec)
 if old.getchannel('A').getbbox() is None:
  report.append({'file':path.name,'status':'preserved blank tile'});continue
 new=decorate(old,tile)
 rebuilt,ranges=replace_texture(data,rec,new)
 assert len(rebuilt)==len(data)
 # Every byte outside the existing texture payloads is unchanged.
 expected=bytearray(data)
 for start,size in ranges:expected[start:start+size]=rebuilt[start:start+size]
 assert bytes(expected)==rebuilt
 out=OUT/'stream'/path.name;out.write_bytes(pack(raw[:16],rebuilt))
 loaded,newrecs=records(out.read_bytes());assert recs==newrecs
 decoded=decode(loaded,rec);assert np.array_equal(np.asarray(decoded)[:,:,3],np.asarray(old)[:,:,3])
 if not path.stem.startswith('minimap_sea_'):
  decoded.save(PREVIEW/(tile+'.png'));base_images[tile]=decoded;old_images[tile]=old
 report.append({'file':path.name,'status':'restyled','dimensions':[rec['width'],rec['height']],'mips':rec['levels'],'alpha':'original BC3 alpha blocks retained','sha256':hashlib.sha256(out.read_bytes()).hexdigest()})
 print('Rebuilt',path.name,flush=True)

# The far-zoom overview uses the identical full 2 x 3 tile extent. Do not crop
# this image: doing so would change its map coordinates relative to the tiles.
composites=[]
for bank in [old_images,base_images]:
 canvas=Image.new('RGBA',(2048,3072))
 for y in range(3):
  for x in range(2):
   tile=f'minimap_{y}_{x}'
   if tile in bank:canvas.paste(bank[tile].resize((1024,1024),Image.Resampling.LANCZOS),(x*1024,y*1024))
 composites.append(canvas)
# The LOD is recolored in place above; its original geographic projection is retained.
report.append({'file':'minimap.ytd','status':'preserved game icon atlases and HUD sprites'})
# Preview crops are for presentation ONLY. Installed textures retain full dimensions.
for canvas,name in zip(composites,['before','after']):
 canvas.crop((360,385,1690,1380)).save(PREVIEW/(name+'.png'))
# Focused detail at native resolution for checking street detail and landmark artwork.
old_images['minimap_0_0'].crop((1680,1760,3072,2870)).save(PREVIEW/'detail-before.png')
base_images['minimap_0_0'].crop((1680,1760,3072,2870)).save(PREVIEW/'detail-after.png')
(ROOT/'validation.json').write_text(json.dumps(report,indent=2)+'\n')
print('Complete. Edited',sum(r['status']=='restyled' for r in report),'YTD files; full dimensions, metadata and transparency retained.')
