from pathlib import Path
import struct,zlib,io,json,sys
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parents[1];original=Path(sys.argv[1]);updated=root/'mini-map';checks=0;changed=[]
def check(ok,msg):
 global checks
 assert ok,msg;checks+=1

def inspect(raw):
 data=zlib.decompress(raw[16:],-15)
 def q(p):return struct.unpack_from('<Q',data,p)[0]
 def ptr(p):return p-0x50000000 if p>>28==5 else p-0x60000000+8192
 listing=ptr(q(0x30));num=struct.unpack_from('<H',data,0x38)[0];records=[]
 for i in range(num):
  base=ptr(q(listing+i*8));name=ptr(q(base+0x28));w,h=struct.unpack_from('<HH',data,base+0x50)
  records.append((data[name:data.index(0,name)],w,h,data[base+0x5d],ptr(q(base+0x70))))
 return data,records

def dds(payload,w,h):
 hdr=[124,0x81007,h,w,len(payload),0,1]+[0]*11+[32,4,0x35545844,0,0,0,0,0]+[0x1000,0,0,0,0]
 return Image.open(io.BytesIO(b'DDS '+struct.pack('<31I',*hdr)+payload)).convert('RGBA')

for old in sorted((original/'stream').iterdir()):
 new=updated/'stream'/old.name;check(new.exists(),'Missing file '+old.name)
 a,b=old.read_bytes(),new.read_bytes()
 if a==b:continue
 changed.append(old.name);check(old.suffix=='.ytd','Non-texture file changed')
 check(a[:16]==b[:16],old.name+' resource header changed')
 da,ra=inspect(a);db,rb=inspect(b)
 check(len(da)==len(db),'Allocation size changed');check(ra==rb,'Texture directory changed')
 check(da[:8192]==db[:8192],'System/texture metadata changed')
 allowed=bytearray(da)
 for name,w,h,levels,offset in ra:
  for level in range(levels):
   size=((w+3)//4)*((h+3)//4)*16;aa=da[offset:offset+size];bb=db[offset:offset+size]
   check(np.array_equal(np.frombuffer(aa,dtype=np.uint8).reshape(-1,16)[:,:8],np.frombuffer(bb,dtype=np.uint8).reshape(-1,16)[:,:8]),'BC3 alpha changed')
   ia,ib=dds(aa,w,h),dds(bb,w,h)
   check(ia.size==ib.size==(w,h),'Mip dimensions changed')
   check(ia.getchannel('A').tobytes()==ib.getchannel('A').tobytes(),'Decoded alpha mismatch')
   allowed[offset:offset+size]=bb;offset+=size;w=max(1,w//2);h=max(1,h//2)
 check(bytes(allowed)==db,'Bytes changed outside texture payload')
for tile in ['0_0','0_1','1_0','1_1']:
 normal,rn=inspect((updated/'stream'/f'minimap_{tile}.ytd').read_bytes());sea,rs=inspect((updated/'stream'/f'minimap_sea_{tile}.ytd').read_bytes())
 n=rn[0];s=rs[0];w,h=n[1:3];size=((w+3)//4)*((h+3)//4)*16
 check(normal[n[4]:n[4]+size]==sea[s[4]:s[4]+size],'Normal/sea tiles differ')
check(len(changed)==9,'Expected 9 populated map YTDs')
check(not (updated/'client.lua').exists(),'Unexpected HUD script')
(root/'validation-summary.json').write_text(json.dumps({'passed':checks,'changed_ytds':changed,'result':'All checks passed; live FiveM rendering not tested'},indent=2)+'\n')
print(f'PASS: {checks} asset checks; 9 populated YTDs restyled; all mip levels decode; dimensions, alpha, metadata, normal/sea pairs and other assets preserved.')
