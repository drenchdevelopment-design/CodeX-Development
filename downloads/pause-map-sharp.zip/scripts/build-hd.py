"""Upgrade only the Queens/Bronx normal + sea dictionaries to 4096px.
Run after build-map.py, passing the original uploaded mini-map resource.
"""
from pathlib import Path
import sys,struct,json,hashlib,shutil
import numpy as np
from PIL import Image
from ytd import records,decode,encode,bc_size,pack
from cartography import decorate,decorate_queens_hd
ROOT=Path(__file__).resolve().parents[1]
SOURCE=Path(sys.argv[1]);OUT=ROOT/'mini-map';PREVIEW=ROOT/'previews'

def allocation_size(flags):
    fields=[(27,1,0),(26,1,1),(25,1,2),(24,1,3),(17,127,4),(11,63,5),(7,15,6),(5,3,7),(4,1,8)]
    return (512<<(flags&15))*sum(((flags>>bit)&mask)<<shift for bit,mask,shift in fields)

def magnify_alpha(blocks,w,h,factor):
    """Keep BC3 endpoints and replicate 3-bit alpha indices without re-encoding."""
    blocks=blocks.reshape(h//4,w//4,16)
    value=np.zeros((h//4,w//4),np.uint64)
    for i in range(6):value|=blocks[:,:,2+i].astype(np.uint64)<<(8*i)
    index=((value[:,:,None]>>(3*np.arange(16,dtype=np.uint64)))&7).astype(np.uint8)
    pixels=index.reshape(h//4,w//4,4,4).transpose(0,2,1,3).reshape(h,w)
    pixels=np.repeat(np.repeat(pixels,factor,axis=0),factor,axis=1)
    indices=pixels.reshape(h*factor//4,4,w*factor//4,4).transpose(0,2,1,3).reshape(-1,16)
    packed=np.sum(indices.astype(np.uint64)<<(3*np.arange(16,dtype=np.uint64)),axis=1,dtype=np.uint64)
    result=np.empty((len(packed),8),np.uint8)
    result[:,:2]=np.repeat(np.repeat(blocks[:,:,:2],factor,axis=0),factor,axis=1).reshape(-1,2)
    for i in range(6):result[:,2+i]=((packed>>(8*i))&255).astype(np.uint8)
    return result

reports=[];art=None
for name in ['minimap_0_1.ytd','minimap_sea_0_1.ytd']:
    raw=(SOURCE/'stream'/name).read_bytes();data,recs=records(raw)
    assert len(recs)==1
    rec=recs[0];assert (rec['width'],rec['height'],rec['levels'],rec['pixels'])==(1024,1024,9,8192)
    assert rec['depth']==1 and rec['format']==0x35545844
    original=decode(data,rec)
    if art is None:
        before=decorate(original,'minimap_0_1')
        before.save(PREVIEW/'queens-before-source.png')
        art=decorate_queens_hd(original)
        art.save(PREVIEW/'queens-hd-master.png')
    levels=[];source_mips=[];pos=rec['pixels'];w=h=1024
    for level in range(rec['levels']):
        size=bc_size(w,h);source_mips.append(data[pos:pos+size]);pos+=size;w//=2;h//=2
    w=h=4096
    for level in range(11):
        pixels=art if level==0 else art.resize((w,h),Image.Resampling.LANCZOS)
        payload=bytearray(encode(pixels));blocks=np.frombuffer(payload,np.uint8).reshape(-1,16)
        if level<2:
            blocks[:,:8]=magnify_alpha(np.frombuffer(source_mips[0],np.uint8),1024,1024,4>>level)
        else:
            blocks[:,:8]=np.frombuffer(source_mips[level-2],np.uint8).reshape(-1,16)[:,:8]
        levels.append(bytes(payload));w//=2;h//=2
    header=bytearray(raw[:16]);sysflags,gfxflags=struct.unpack_from('<II',header,8)
    assert allocation_size(sysflags)==8192
    # Same page count and all virtual pointers, with a 16x larger graphics page.
    newflags=(gfxflags&~15)|((gfxflags&15)+4)
    assert (gfxflags&15)+4<=15
    struct.pack_into('<I',header,12,newflags)
    metadata=bytearray(data[:8192]);base=rec['structure']
    struct.pack_into('<HH',metadata,base+0x50,4096,4096)
    struct.pack_into('<H',metadata,base+0x56,4096)
    metadata[base+0x5d]=11
    payload=b''.join(levels);budget=allocation_size(newflags)
    assert len(payload)<=budget
    rebuilt=bytes(metadata)+payload+bytes(budget-len(payload))
    dest=OUT/'stream'/name;dest.write_bytes(pack(bytes(header),rebuilt))
    reread,newrecs=records(dest.read_bytes());decoded=decode(reread,newrecs[0])
    if name=='minimap_0_1.ytd':
        decoded.save(PREVIEW/'minimap_0_1.png')
        # Identical map extent and display zoom for honest before/after comparison.
        box=(0,515,610,1015)
        before.crop(box).resize((1220,1000),Image.Resampling.BILINEAR).save(PREVIEW/'queens-before.png')
        decoded.crop(tuple(v*4 for v in box)).resize((1220,1000),Image.Resampling.LANCZOS).save(PREVIEW/'queens-after.png')
    reports.append({'file':name,'dimensions':[4096,4096],'mips':11,'graphics_allocation':budget,'texture_bytes':len(payload),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest()})
    print('Rebuilt',name,'4096x4096, 11 mips, alpha remapped exactly',flush=True)
# Refresh both overviews at identical UV extent; before uses the v5 artwork.
canvas=Image.new('RGBA',(2048,3072));previous=Image.new('RGBA',(2048,3072))
for y,x in [(0,0),(0,1),(1,0),(1,1)]:
    tile=Image.open(PREVIEW/f'minimap_{y}_{x}.png').convert('RGBA')
    canvas.paste(tile.resize((1024,1024),Image.Resampling.LANCZOS),(x*1024,y*1024))
    old_tile=before if (y,x)==(0,1) else tile
    previous.paste(old_tile.resize((1024,1024),Image.Resampling.LANCZOS),(x*1024,y*1024))
canvas.crop((360,385,1690,1380)).save(PREVIEW/'after.png')
previous.crop((360,385,1690,1380)).save(PREVIEW/'before.png')
shutil.copyfile(PREVIEW/'queens-before.png',PREVIEW/'detail-before.png')
shutil.copyfile(PREVIEW/'queens-after.png',PREVIEW/'detail-after.png')
p=OUT/'fxmanifest.lua';p.write_text(p.read_text().replace("version '5.0.0'","version '5.1.0'"))
(ROOT/'hd-build.json').write_text(json.dumps(reports,indent=2)+'\n')
