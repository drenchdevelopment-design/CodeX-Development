"""Phone-map-inspired colors and original, procedural landmark illustrations.
Coordinates use the original tile extent. HD output redraws paths and labels.
"""
from pathlib import Path
import math
import cv2
from skimage.morphology import skeletonize
import numpy as np
from PIL import Image,ImageDraw,ImageFont,ImageFilter
ROOT=Path(__file__).resolve().parents[1]
FONT=str(ROOT/'source/fonts/DejaVuSans.ttf');BOLD=str(ROOT/'source/fonts/DejaVuSans-Bold.ttf')
OLD_LABELS={
 'minimap_0_0':[(1926,1826,2330,1922),(2502,2022,2900,2132),(1770,2304,2162,2400),(2556,2672,2950,2768)],
 'minimap_0_1':[(54,551,189,615),(165,845,360,904)],
 'minimap_1_0':[(1658,96,2078,180)],'minimap_1_1':[(360,94,774,202)]}

def park_mask(tile,size):
    im=Image.new('L',size);d=ImageDraw.Draw(im)
    if tile=='minimap_0_0':d.polygon([(2645,2158),(2840,2158),(2840,2500),(2645,2500)],fill=255)
    if tile=='minimap_0_1':
        d.polygon([(36,748),(73,745),(80,831),(37,835)],fill=255)
        d.polygon([(124,778),(157,778),(155,833),(123,833)],fill=255)
        d.polygon([(350,836),(390,838),(397,913),(358,920)],fill=255)
    if tile=='minimap_1_0':d.polygon([(2378,353),(2420,308),(2470,309),(2515,359),(2573,557),(2500,622),(2416,592),(2370,461)],fill=255)
    return np.asarray(im)>0

def segments(values):
    active=np.flatnonzero(values)
    if not len(active):return []
    groups=np.split(active,np.flatnonzero(np.diff(active)>1)+1)
    return [(float(g.mean()),len(g)) for g in groups if len(g)>1]

def repair_titles(roads,tile):
    """Continue visible road entries through the old, flattened title footprints.
    These short interpolations are limited to pixels obscured by original type.
    """
    result=roads.copy();scale=roads.shape[0]/3072
    for x0,y0,x1,y1 in OLD_LABELS.get(tile,[]):
        # Include the title's extrusion and antialiasing in the replacement.
        x0-=2;y0-=2;x1+=2;y1+=2
        top=segments(np.max(roads[y0-3:y0,x0:x1],axis=0)>0)
        bottom=segments(np.max(roads[y1:y1+3,x0:x1],axis=0)>0)
        left=segments(np.max(roads[y0:y1,x0-3:x0],axis=1)>0)
        right=segments(np.max(roads[y0:y1,x1:x1+3],axis=1)>0)
        result[y0:y1,x0:x1]=0
        overlay=np.zeros_like(roads)
        for first,second,vertical in [(top,bottom,True),(left,right,False)]:
            used=set()
            for pos,width in first:
                candidates=[(abs(pos-other),i,other,w) for i,(other,w) in enumerate(second) if i not in used]
                if not candidates:continue
                gap,i,other,w=min(candidates)
                if gap>max(6,20*scale) or max(width,w)>max(22,50*scale):continue
                used.add(i);thickness=max(2,round(min(width,w)))
                if vertical:a=(round(x0+pos),y0);b=(round(x0+other),y1)
                else:a=(x0,round(y0+pos));b=(x1,round(y0+other))
                cv2.line(overlay,a,b,255,thickness,cv2.LINE_AA)
        result[y0:y1,x0:x1]=overlay[y0:y1,x0:x1]
    return result

def palette(im,tile,output_scale=1):
    a=np.asarray(im);rgb=a[:,:,:3].astype(np.float32)
    r,g,b=rgb.transpose(2,0,1);lum=rgb.mean(axis=2);n=im.width/3072
    water=(b-r>7)&(b-g>-2)
    count,components,stats,_=cv2.connectedComponentsWithStats(water.astype(np.uint8),8)
    valid=stats[:,cv2.CC_STAT_AREA]>max(70,2000*n*n);valid[0]=False
    water=valid[components]
    land=(~water)&(a[:,:,3]>0)&(lum>10)
    # Solid near-black water and quiet navy blocks, as in the reference.
    out=np.empty_like(rgb);out[:]=[10,16,21]
    out[land]=[23,36,51]
    buildings=land&(lum>49)&(lum<85)
    out[buildings]=[25,39,54]
    # Ignore the source's white lettering; retain grey street geometry.
    road=((lum>87)&(lum<207)&(np.max(rgb,axis=2)-np.min(rgb,axis=2)<23)&land).astype(np.uint8)*255
    kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(3,3))
    close_size=max(3,round(11*n))|1
    close_kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(close_size,close_size))
    road=cv2.morphologyEx(road,cv2.MORPH_CLOSE,close_kernel)
    road=cv2.morphologyEx(road,cv2.MORPH_OPEN,kernel)
    road=repair_titles(road,tile)
    # Recover the land tone under old titles before adding compact plain labels.
    for x0,y0,x1,y1 in OLD_LABELS.get(tile,[]):
        out[y0-2:y1+2,x0-2:x1+2]=[23,36,51]
        land[y0-2:y1+2,x0-2:x1+2]=True
    distance=cv2.distanceTransform((~water).astype(np.uint8),cv2.DIST_L2,3)
    coastal=land&(distance<max(5,32*n))
    out[coastal]=[23,55,57]
    parks=park_mask(tile,im.size)
    out[parks&land]=[22,58,52]
    out[parks&(lum>218)]=[9,19,25]
    background=out.copy()
    # Reduce the raster road fill to a clean centerline network. Width now
    # depends on road class, rather than source lettering and building noise.
    thin=skeletonize(road>0).astype(np.uint8)
    for _ in range(max(1,round(3*n))):
        neighbors=cv2.filter2D(thin,cv2.CV_16S,np.ones((3,3),np.uint8))-thin
        thin[(thin>0)&(neighbors<=1)]=0
    radius=max(1,round(3*n));stroke_kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(radius*2+1,)*2)
    clean=cv2.dilate(thin,stroke_kernel).astype(float)
    case_kernel=cv2.getStructuringElement(cv2.MORPH_ELLIPSE,(radius*2+3,)*2)
    casing=cv2.dilate(thin,case_kernel).astype(float)
    out=out*(1-casing[:,:,None])+np.array([30,47,65])*casing[:,:,None]
    out=out*(1-clean[:,:,None])+np.array([65,85,112])*clean[:,:,None]
    # Wide original arteries receive a subtle lighter center line.
    distance_road=cv2.distanceTransform((road>0).astype(np.uint8),cv2.DIST_L2,3)
    major=((thin>0)&(distance_road>max(3,8*n))).astype(np.uint8)
    _,groups,stats,_=cv2.connectedComponentsWithStats(major,8)
    keep=stats[:,cv2.CC_STAT_AREA]>max(14,60*n);keep[0]=False
    major=keep[groups].astype(np.uint8)
    major=cv2.dilate(major,np.ones((max(1,round(2*n)),)*2,np.uint8)).astype(float)
    out=out*(1-major[:,:,None])+np.array([137,156,173])*major[:,:,None]
    if output_scale>1:
        return render_hd(a,background,thin,major,radius,output_scale)
    # Preserve every original alpha block when the YTD is rebuilt.
    result=np.empty_like(a);result[:,:,:3]=np.uint8(np.clip(out,0,255));result[:,:,3]=a[:,:,3]
    result[np.max(a[:,:,:3],axis=2)<5,:3]=0
    return Image.fromarray(result)

def render_hd(original,background,thin,major,radius,scale):
    """Re-rasterize road paths at output resolution over the existing terrain.
    Labels are added afterward at native output size, never enlarged from pixels.
    """
    height,width=thin.shape
    out=cv2.resize(np.uint8(background),(width*scale,height*scale),interpolation=cv2.INTER_LINEAR)
    def contours(mask,epsilon=.6):
        paths,_=cv2.findContours(mask.astype(np.uint8),cv2.RETR_LIST,cv2.CHAIN_APPROX_SIMPLE)
        return [np.rint((cv2.approxPolyDP(p,epsilon,True).astype(float)+.5)*scale-.5).astype(np.int32) for p in paths]
    paths=contours(thin)
    cv2.polylines(out,paths,True,(30,47,65),(radius*2+1)*scale,cv2.LINE_AA)
    cv2.polylines(out,paths,True,(65,85,112),(radius*2)*scale,cv2.LINE_AA)
    paths=contours(major)
    cv2.polylines(out,paths,True,(137,156,173),scale,cv2.LINE_AA)
    # Tile UVs and transparency are unchanged; BC3 alpha is also remapped exactly
    # from the original blocks by build-hd.py when writing the dictionaries.
    blank=cv2.resize((np.max(original[:,:,:3],axis=2)<5).astype(np.uint8),(width*scale,height*scale),interpolation=cv2.INTER_NEAREST)>0
    out[blank]=0
    alpha=cv2.resize(original[:,:,3],(width*scale,height*scale),interpolation=cv2.INTER_NEAREST)
    return Image.fromarray(np.dstack((out,alpha)))

def decorate_queens_hd(im):
    scale=4
    im=palette(im,'minimap_0_1',output_scale=scale)
    label(im,'The Bronx',(130*scale,579*scale),21*scale,stroke=scale)
    label(im,'Queens',(269*scale,862*scale),22*scale,stroke=scale)
    park_pin(im,(46*scale,770*scale),"Randall's\nIsland Park",scale=scale)
    park_pin(im,(129*scale,809*scale),'Astoria Park',scale=scale)
    park_pin(im,(359*scale,883*scale),'Flushing Meadows\nCorona Park',scale=scale)
    poi_pin(im,(453*scale,948*scale),'JFK International\nAirport',kind='airport',scale=scale)
    poi_pin(im,(12*scale,919*scale),'Blackwell Island\nLighthouse',scale=scale)
    return im

def label(im,text,xy,size,color=(235,240,247,255),bold=False,anchor='mm',stroke=2):
    d=ImageDraw.Draw(im);font=ImageFont.truetype(BOLD if bold else FONT,size)
    d.text(xy,text,font=font,fill=color,anchor=anchor,stroke_width=stroke,stroke_fill=(12,20,32,255))

def landmark(kind):
    # Supersampled original vector miniatures; the final badge is antialiased.
    im=Image.new('RGBA',(384,410));d=ImageDraw.Draw(im)
    d.ellipse((22,20,362,360),fill=(9,16,27,160))
    d.ellipse((28,16,356,344),fill=(22,33,51,255),outline=(164,182,207,255),width=6)
    d.ellipse((38,26,346,334),outline=(64,84,111,255),width=2)
    d.polygon([(175,342),(192,371),(209,342)],fill=(164,182,207,255))
    art_path=ROOT/'source/landmarks/illustrations'/(kind+'.png')
    if art_path.exists():
        art=Image.open(art_path).convert('RGBA')
        art.thumbnail((294,294),Image.Resampling.LANCZOS)
        im.alpha_composite(art,((384-art.width)//2,30+(294-art.height)//2))
        return im
    def building(x,y,w,h,front,side,roof):
        dx=19
        d.polygon([(x,y),(x+w,y),(x+w,y+h),(x,y+h)],fill=front)
        d.polygon([(x+w,y),(x+w+dx,y-12),(x+w+dx,y+h-12),(x+w,y+h)],fill=side)
        d.polygon([(x,y),(x+dx,y-12),(x+w+dx,y-12),(x+w,y)],fill=roof)
        for yy in range(y+12,y+h-8,19):
            for xx in range(x+7,x+w-4,13):d.rectangle((xx,yy,xx+4,yy+7),fill=(153,181,205,255))
    if kind=='times-square':
        d.polygon([(64,282),(178,242),(320,284),(205,316)],fill=(57,68,89,255))
        building(80,149,42,126,(69,83,114),(39,55,83),(118,132,153))
        building(133,81,55,202,(99,114,132),(52,70,93),(165,177,190))
        building(214,116,51,171,(63,77,106),(35,51,77),(130,148,168))
        building(277,180,30,105,(91,86,117),(51,55,89),(143,137,163))
        d.line((159,82,159,46),fill=(194,210,220),width=4)
        for box,color in [((137,123,183,163),(104,157,246)),((138,177,183,214),(204,114,232)),((217,150,260,190),(239,194,106)),((82,200,118,239),(83,213,204)),((219,205,261,251),(233,128,151))]:
            d.rectangle(box,fill=color);d.line((box[0]+5,box[1]+9,box[2]-5,box[1]+9),fill=(240,246,255),width=3)
        d.polygon([(179,284),(189,228),(207,228),(231,294),(205,305)],fill=(169,188,218))
        d.line((192,277,222,287),fill=(243,212,145),width=3)
    elif kind=='brooklyn-bridge':
        d.polygon([(61,255),(198,199),(327,258),(190,311)],fill=(27,64,86))
        for y in [265,278,291]:d.line((100,y,175,y+15),fill=(60,102,125),width=2)
        d.polygon([(63,248),(74,233),(318,190),(327,207)],fill=(163,158,147))
        d.line((69,239,323,195),fill=(227,220,199),width=5)
        # Two recognizable Gothic stone towers with paired pointed arches.
        for x,y in [(119,128),(245,107)]:
            d.polygon([(x,y),(x+46,y-8),(x+46,y+125),(x,y+134)],fill=(189,179,148))
            d.polygon([(x+46,y-8),(x+57,y-15),(x+57,y+117),(x+46,y+125)],fill=(119,119,110))
            d.polygon([(x-3,y),(x+45,y-8),(x+56,y-15),(x+9,y-8)],fill=(219,208,180))
            for off in [8,27]:
                d.polygon([(x+off,y+100),(x+off,y+33),(x+off+7,y+19),(x+off+14,y+30),(x+off+14,y+98)],fill=(28,41,54))
            d.line((x,y+13,x+46,y+5),fill=(232,218,184),width=3)
        # Suspension cables follow catenary-like curves between the towers.
        for start,end in [((75,218),(135,127)),((138,126),(265,104)),((265,104),(324,186))]:
            pts=[]
            for i in range(31):
                t=i/30;x=start[0]*(1-t)+end[0]*t;y=start[1]*(1-t)+end[1]*t+33*math.sin(math.pi*t)
                pts.append((x,y))
            d.line(pts,fill=(208,217,225),width=3)
            for x,y in pts[::4]:d.line((x,y,x,237-(x-75)*.17),fill=(140,160,180),width=1)
    elif kind=='statue-of-liberty':
        d.ellipse((80,267,302,308),fill=(29,65,59))
        d.polygon([(143,267),(154,241),(230,241),(245,275),(191,294)],fill=(162,154,135))
        d.polygon([(156,241),(166,205),(218,205),(230,241)],fill=(186,174,150))
        d.polygon([(169,204),(175,154),(185,131),(207,133),(214,163),(226,214)],fill=(93,168,146))
        d.polygon([(185,135),(199,139),(207,212),(177,211)],fill=(130,196,171))
        d.line((188,153,184,199),fill=(62,124,115),width=4)
        d.line((203,158,214,209),fill=(65,135,120),width=3)
        d.polygon([(181,140),(163,124),(154,91),(165,88),(177,116),(195,134)],fill=(127,190,164))
        d.rectangle((153,77,166,92),fill=(122,181,158))
        d.polygon([(153,77),(151,66),(158,54),(165,67),(166,77)],fill=(239,204,122))
        d.ellipse((179,106,204,136),fill=(132,194,166))
        d.arc((176,100,209,132),180,355,fill=(171,220,192),width=5)
        for x,y in [(174,98),(183,88),(194,85),(207,92),(216,101)]:d.line((192,112,x,y),fill=(157,211,183),width=4)
        d.polygon([(207,147),(223,150),(216,180),(201,175)],fill=(73,139,130))
        d.rectangle((209,146,224,174),fill=(144,197,175))
    return im

ICON_CACHE={}
def badge(im,kind,center,size,title):
    if kind not in ICON_CACHE:
        ICON_CACHE[kind]=landmark(kind)
        assets=ROOT/'source/landmarks';assets.mkdir(exist_ok=True)
        ICON_CACHE[kind].save(assets/(kind+'.png'))
    icon=ICON_CACHE[kind].resize((size,int(size*410/384)),Image.Resampling.LANCZOS)
    x,y=center;im.alpha_composite(icon,(int(x-size/2),int(y-size/2)))
    # Names remain legible but secondary to the major neighborhood labels.
    label(im,title.upper(),(x,y+size*.60),max(17,int(size*.105)),bold=False,stroke=2)

def park_pin(im,xy,title,scale=3):
    x,y=xy;d=ImageDraw.Draw(im);r=6*scale
    d.ellipse((x-r,y-r,x+r,y+r),fill=(57,119,90),outline=(103,158,120),width=scale)
    d.polygon([(x,y-4*scale),(x-3*scale,y+2*scale),(x+3*scale,y+2*scale)],fill=(15,41,31))
    d.line((x,y+2*scale,x,y+4*scale),fill=(15,41,31),width=scale)
    label(im,title,(x+10*scale,y),8*scale,color=(109,174,131,255),bold=False,anchor='lm',stroke=max(1,scale//2))

def poi_pin(im,xy,title,kind='place',scale=1):
    x,y=xy;d=ImageDraw.Draw(im);r=6*scale
    color=(71,125,180,255) if kind=='airport' else (139,160,170,255)
    d.ellipse((x-r,y-r,x+r,y+r),fill=color)
    ink=(20,40,55,255)
    if kind=='airport':
        d.line((x,y-4*scale,x,y+4*scale),fill=ink,width=max(1,scale))
        d.line((x-4*scale,y,x+4*scale,y),fill=ink,width=max(1,scale))
        d.line((x-2*scale,y+3*scale,x+2*scale,y+3*scale),fill=ink,width=max(1,scale))
    else:
        d.rectangle((x-scale,y-2*scale,x+scale,y+3*scale),fill=ink)
        d.polygon([(x-2*scale,y-2*scale),(x,y-4*scale),(x+2*scale,y-2*scale)],fill=ink)
    label(im,title,(x+9*scale,y),8*scale,color=color,bold=False,anchor='lm',stroke=max(1,scale//2))

def decorate(im,tile):
    im=palette(im,tile)
    if tile=='minimap_0_0':
        label(im,'Woodbridge',(2128,1874),27,color=(162,180,190,255))
        label(im,'Harlem',(2701,2077),57)
        label(im,'New Jersey',(1966,2352),57)
        label(im,'Manhattan',(2753,2820),59)
        park_pin(im,(2675,2290),'Central Park')
        badge(im,'times-square',(2680,2560),212,'Times Square')
    elif tile=='minimap_0_1':
        label(im,'The Bronx',(130,579),21,stroke=1)
        label(im,'Queens',(269,862),22,stroke=1)
        park_pin(im,(46,770),"Randall's\nIsland Park",scale=1)
        park_pin(im,(129,809),'Astoria Park',scale=1)
        park_pin(im,(359,883),'Flushing Meadows\nCorona Park',scale=1)
        poi_pin(im,(453,948),'JFK International\nAirport',kind='airport')
        poi_pin(im,(12,919),'Blackwell Island\nLighthouse')
    elif tile=='minimap_1_0':
        label(im,'East Jersey State Prison',(1865,139),29,bold=False,stroke=2)
        badge(im,'statue-of-liberty',(2462,426),212,'Statue of Liberty')
        label(im,'Liberty Island',(2480,663),31,bold=False,stroke=2)
    elif tile=='minimap_1_1':
        label(im,'Brooklyn',(645,162),61)
        badge(im,'brooklyn-bridge',(189,112),212,'Brooklyn Bridge')
        poi_pin(im,(735,486),'Coney Island Beach\n& Boardwalk',scale=3)
    return im
