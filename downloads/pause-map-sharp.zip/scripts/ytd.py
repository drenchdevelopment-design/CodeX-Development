"""RSC7 single-texture decoding and BC3 helpers for the supplied resource."""
import struct,zlib,io
import numpy as np
from PIL import Image

def records(raw):
 assert raw[:4]==b'RSC7' and struct.unpack_from('<I',raw,8)[0]==0x20000,'Unexpected resource layout'
 data=zlib.decompress(raw[16:],-15)
 def u64(p):return struct.unpack_from('<Q',data,p)[0]
 def ptr(v):
  if v>>28==5:return v-0x50000000
  if v>>28==6:return v-0x60000000+8192
  raise ValueError(f'Unknown pointer {v:x}')
 listing=ptr(u64(0x30));count=struct.unpack_from('<H',data,0x38)[0];out=[]
 for i in range(count):
  pos=ptr(u64(listing+8*i));n=ptr(u64(pos+0x28));name=data[n:data.index(0,n)].decode()
  w,h,depth,stride,fmt=struct.unpack_from('<HHHHI',data,pos+0x50)
  out.append(dict(name=name,width=w,height=h,depth=depth,stride=stride,format=fmt,levels=data[pos+0x5d],structure=pos,pixels=ptr(u64(pos+0x70))))
 return data,out

def bc_size(w,h):return ((w+3)//4)*((h+3)//4)*16

def decode(data,record):
 w,h=record['width'],record['height'];size=bc_size(w,h)
 header=[124,0x81007,h,w,size,0,1]+[0]*11+[32,4,0x35545844,0,0,0,0,0]+[0x1000,0,0,0,0]
 return Image.open(io.BytesIO(b'DDS '+struct.pack('<31I',*header)+data[record['pixels']:record['pixels']+size])).convert('RGBA')


def encode(im):
 b=io.BytesIO();im.save(b,format='DDS',pixel_format='DXT5');raw=b.getvalue();assert raw[:4]==b'DDS ' and raw[84:88]==b'DXT5'
 return raw[128:]

def replace_texture(data,rec,im,keep_alpha=True):
 data=bytearray(data);w,h=rec['width'],rec['height'];offset=rec['pixels'];sizes=[]
 for level in range(rec['levels']):
  size=bc_size(w,h);scaled=im if level==0 else im.resize((w,h),Image.Resampling.LANCZOS)
  packed=bytearray(encode(scaled));assert len(packed)==size
  if keep_alpha:
   # Retain the original BC3 alpha endpoints/indices EXACTLY, at every mip.
   dst=np.frombuffer(packed,dtype=np.uint8).reshape(-1,16)
   src=np.frombuffer(data[offset:offset+size],dtype=np.uint8).reshape(-1,16)
   dst[:,:8]=src[:,:8]
  data[offset:offset+size]=packed;sizes.append((offset,size));offset+=size;w=max(1,w//2);h=max(1,h//2)
 return bytes(data),sizes

def pack(header,data):
 compress=zlib.compressobj(9,zlib.DEFLATED,-15)
 return header+compress.compress(data)+compress.flush()

