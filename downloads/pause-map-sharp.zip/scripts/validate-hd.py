"""Validate upgraded RSC7 allocations, mip chains, alpha and change scope.
Usage: python scripts/validate-hd.py /path/to/original/mini-map
"""
from pathlib import Path
import sys,struct,zlib,io,json,hashlib
import numpy as np
from PIL import Image
root=Path(__file__).resolve().parents[1];source=Path(sys.argv[1]);target=root/'mini-map'
checks=0
changed={'stream/minimap_0_1.ytd','stream/minimap_sea_0_1.ytd'}
def check(value,message):
    global checks
    assert value,message
    checks+=1

def inspect(raw):
    check(raw[:4]==b'RSC7','RSC7 magic')
    system,graphics=struct.unpack_from('<II',raw,8)
    def allocation(f):
        page_base=512<<(f&15)
        sizes=[256,128,64,32,16,8,4,2,1]
        fields=[(4,1),(5,3),(7,15),(11,63),(17,127),(24,1),(25,1),(26,1),(27,1)]
        counts=[(f>>offset)&mask for offset,mask in fields]
        return page_base*sum(a*b for a,b in zip(sizes,counts)),sum(counts)
    sys_size,sys_count=allocation(system);gfx_size,gfx_count=allocation(graphics)
    data=zlib.decompress(raw[16:],-15)
    check(len(data)==sys_size+gfx_size,'RSC7 page allocation matches decompressed bytes')
    def q(p):return struct.unpack_from('<Q',data,p)[0]
    def system_ptr(p):
        check(p>>28==5,'System pointer segment');p-=0x50000000
        check(0<=p<sys_size,'System pointer in allocation');return p
    pages=system_ptr(q(8))
    check(data[pages+8]==sys_count and data[pages+9]==gfx_count,'Page counts match header flags')
    listing=system_ptr(q(0x30));check(struct.unpack_from('<H',data,0x38)[0]==1,'One texture')
    base=system_ptr(q(listing));name=system_ptr(q(base+0x28))
    check(q(base+0x70)>>28==6,'Graphics pointer segment')
    offset=sys_size+q(base+0x70)-0x60000000
    w,h,depth,stride,fmt=struct.unpack_from('<HHHHI',data,base+0x50)
    return data,dict(base=base,name=data[name:data.index(0,name)],w=w,h=h,depth=depth,stride=stride,fmt=fmt,levels=data[base+0x5d],offset=offset,sys_size=sys_size,gfx_size=gfx_size)

def decode(payload,w,h):
    hdr=[124,0x81007,h,w,len(payload),0,1]+[0]*11+[32,4,0x35545844,0,0,0,0,0]+[0x1000,0,0,0,0]
    return Image.open(io.BytesIO(b'DDS '+struct.pack('<31I',*hdr)+payload)).convert('RGBA')

def mips(data,rec):
    w,h,offset=rec['w'],rec['h'],rec['offset'];images=[];payloads=[]
    for level in range(rec['levels']):
        size=((w+3)//4)*((h+3)//4)*16
        check(offset+size<=len(data),'Mip allocation bounds')
        payload=data[offset:offset+size];im=decode(payload,w,h)
        check(im.size==(w,h),'Mip dimensions decode correctly')
        images.append(im);payloads.append(payload)
        offset+=size;w=max(1,w//2);h=max(1,h//2)
    check(not any(data[offset:]),'Unused graphics page padding is zero')
    return images,payloads

hashes=json.loads((root/'source/v5-asset-hashes.json').read_text())
check({str(p.relative_to(target)) for p in (target/'stream').iterdir()}==set(hashes),'Runtime file set preserved')
for name,digest in hashes.items():
    if name in changed:continue
    check(hashlib.sha256((target/name).read_bytes()).hexdigest()==digest,'Unchanged asset '+name)
new_mips=[]
for name in sorted(changed):
    old=(source/name).read_bytes();new=(target/name).read_bytes()
    a,ra=inspect(old);b,rb=inspect(new)
    check((rb['w'],rb['h'],rb['stride'],rb['levels'])==(4096,4096,4096,11),'4K dimensions, legacy BC3 stride, 11 mips')
    check(rb['gfx_size']==32*1024*1024,'32 MiB single graphics page')
    check(rb['fmt']==ra['fmt']==0x35545844 and rb['depth']==ra['depth']==1,'BC3 format and depth retained')
    check(rb['name']==ra['name'],'Original texture name retained')
    check(rb['offset']==ra['offset']==8192,'Original graphics pointer and allocation start retained')
    check(old[:12]==new[:12],'Version and system allocation unchanged')
    check((struct.unpack_from('<I',old,12)[0]&~15)==(struct.unpack_from('<I',new,12)[0]&~15),'Only graphics page size shift changed')
    expected=bytearray(a[:8192]);base=ra['base']
    struct.pack_into('<HH',expected,base+0x50,4096,4096);struct.pack_into('<H',expected,base+0x56,4096);expected[base+0x5d]=11
    check(bytes(expected)==b[:8192],'Only width, height, stride and mip count changed in metadata')
    old_images,old_payloads=mips(a,ra);new_images,new_payloads=mips(b,rb)
    check(sum(len(p) for p in new_payloads)==sum((rb['stride']*rb['h'])//(4**level) for level in range(rb['levels'])),'Legacy TextureData stride/height reader consumes exact mip payload')
    for level,im in enumerate(new_images):
        original=old_images[max(0,level-2)]
        alpha=original.getchannel('A').resize(im.size,Image.Resampling.NEAREST)
        check(im.getchannel('A').tobytes()==alpha.tobytes(),'Exact original transparency in mip '+str(level))
        if level>=2:
            check(np.array_equal(np.frombuffer(new_payloads[level],np.uint8).reshape(-1,16)[:,:8],np.frombuffer(old_payloads[level-2],np.uint8).reshape(-1,16)[:,:8]),'Original lower-level alpha blocks retained')
    check(np.asarray(new_images[0])[:,:,:3].max()>200,'Populated color payload')
    new_mips.append(new_payloads)
check(new_mips[0]==new_mips[1],'Normal and sea color/alpha payloads match at every mip')
report={'passed':checks,'changed_ytds':sorted(changed),'dimensions':[4096,4096],'mips':11,'result':'All HD texture checks passed; live FiveM not tested'}
(root/'hd-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'PASS: {checks} HD checks; 4K normal/sea textures, valid RSC7 allocations, every mip decoded, exact alpha at matching scales, other assets unchanged.')
