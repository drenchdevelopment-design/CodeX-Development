const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const path=require('node:path');
const {pathToFileURL}=require('node:url');
const root=path.resolve(__dirname,'..');
(async()=>{
const browser=await chromium.launch({headless:true,executablePath:process.env.CHROMIUM_EXECUTABLE,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1440,height:1080}});let errors=[],network=[];
page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/^https?:/.test(r.url()))network.push(r.url())});
await page.goto(pathToFileURL(path.join(root,'preview.html')).href);await page.waitForFunction(()=>document.getElementById('after').complete);
assert.equal(await page.locator('#after').evaluate(i=>i.naturalWidth),1330);
await page.locator('#compare').fill('0');assert.equal(await page.locator('#divider').evaluate(i=>i.style.left),'0%');
await page.locator('#detail').click();await page.waitForFunction(()=>document.getElementById('after').complete);
assert.equal(await page.locator('#after').evaluate(i=>i.naturalWidth),1220);
assert.equal(await page.locator('#detail').getAttribute('aria-pressed'),'true');
await page.locator('#overview').click();await page.screenshot({path:path.join(root,'previews/comparison-desktop.png'),fullPage:true});
await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
assert.deepEqual(errors,[]);assert.deepEqual(network,[]);await browser.close();console.log('PASS: preview images decode, comparison slider, detail view, mobile fit and offline operation.');
})().catch(e=>{console.error(e);process.exit(1)});
