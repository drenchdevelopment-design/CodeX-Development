local lastLayout = ''
local scaleform = nil
local stopped = false
local visible = false

local function layout()
    local width, height = GetActiveScreenResolution()
    local safezone = GetSafeZoneSize()
    local signature = ('%s:%s:%.3f'):format(width, height, safezone)
    if signature == lastLayout then return end
    lastLayout = signature

    local rect = Config.CustomPlacement and Config.Placement or
        {x=-0.0045, y=0.002, width=0.150, height=0.188888}
    if Config.CustomPlacement then
        -- Reserve space for the information panel at lower display resolutions.
        rect = {x=rect.x, y=math.min(rect.y, -(height <= 760 and 64 or 76) / height),
            width=rect.width, height=rect.height}
        SetMinimapClipType(0)
        SetMinimapComponentPosition('minimap', 'L', 'B', rect.x, rect.y, rect.width, rect.height)
        SetMinimapComponentPosition('minimap_mask', 'L', 'B', rect.x + 0.0245, rect.y + 0.030, rect.width * 0.74, rect.height * 0.842)
        SetMinimapComponentPosition('minimap_blur', 'L', 'B', rect.x - 0.0255, rect.y + 0.020, rect.width * 1.7733, rect.height * 1.2547)
        SetRadarBigmapEnabled(true, false)
        Wait(0)
        SetRadarBigmapEnabled(false, false)
    end
    -- Query GTA's own alignment transform rather than guessing offsets on ultrawide monitors.
    SetScriptGfxAlign(string.byte('L'), string.byte('B'))
    local left, top = GetScriptGfxPosition(rect.x, rect.y - rect.height)
    local right, bottom = GetScriptGfxPosition(rect.x + rect.width, rect.y)
    ResetScriptGfxAlign()
    SendNUIMessage({action='layout', left=left, top=top, width=right-left, height=bottom-top,
        accent=Config.Accent, vitals=Config.ShowVitals})
end

local function compass(heading)
    local points = {'N','NW','W','SW','S','SE','E','NE'}
    return points[(math.floor((heading + 22.5) / 45) % 8) + 1]
end

CreateThread(function()
    -- NUI requests a layout after loading; this also handles resource restarts.
    scaleform = RequestScaleformMovie('minimap')
    while not stopped do
        layout()
        local ped = PlayerPedId()
        local inVehicle = IsPedInAnyVehicle(ped, false)
        local show = not IsPauseMenuActive() and not IsPlayerSwitchInProgress() and
            not IsScreenFadedOut() and (Config.ShowOnFoot or inVehicle)
        DisplayRadar(show)
        visible = show
        if show then
            local coords = GetEntityCoords(ped)
            local street, crossing = GetStreetNameAtCoord(coords.x, coords.y, coords.z)
            local streetName = street ~= 0 and GetStreetNameFromHashKey(street) or ''
            local crossingName = crossing ~= 0 and GetStreetNameFromHashKey(crossing) or ''
            local zoneLabel = GetLabelText(GetNameOfZone(coords.x, coords.y, coords.z))
            if zoneLabel == 'NULL' then zoneLabel = '' end
            local heading = GetEntityHeading(ped)
            local vehicle = inVehicle and GetVehiclePedIsIn(ped, false) or nil
            local speed = vehicle and GetEntitySpeed(vehicle) or 0
            local maxHealth = math.max(1, GetEntityMaxHealth(ped) - 100)
            local health = math.max(0, math.min(100, (GetEntityHealth(ped) - 100) / maxHealth * 100))
            SendNUIMessage({action='update', visible=true, street=streetName ~= '' and streetName or 'Unknown road',
                district=crossingName ~= '' and crossingName or zoneLabel, compass=compass(heading),
                heading=math.floor((360-heading)%360), speed=math.floor(speed*(Config.SpeedUnit=='kmh' and 3.6 or 2.236936)+0.5),
                unit=Config.SpeedUnit=='kmh' and 'KM/H' or 'MPH', vehicle=inVehicle,
                health=health, armor=math.max(0,math.min(100,GetPedArmour(ped))), waypoint=IsWaypointActive()})
        else
            SendNUIMessage({action='update', visible=false})
        end
        Wait(math.max(100, Config.UpdateInterval or 150))
    end
end)

-- Hide the stock health/armor strip only when this HUD supplies its replacement.
CreateThread(function()
    while not stopped do
        if Config.ShowVitals and visible and scaleform and HasScaleformMovieLoaded(scaleform) then
            BeginScaleformMovieMethod(scaleform, 'SETUP_HEALTH_ARMOUR')
            ScaleformMovieMethodAddParamInt(3)
            EndScaleformMovieMethod()
            Wait(0)
        else
            Wait(250)
        end
    end
end)

RegisterNUICallback('ready', function(_, cb)
    lastLayout = ''
    cb({ok=true})
end)

AddEventHandler('onResourceStop', function(resource)
    if resource ~= GetCurrentResourceName() then return end
    stopped = true
    if scaleform and HasScaleformMovieLoaded(scaleform) then
        BeginScaleformMovieMethod(scaleform, 'SETUP_HEALTH_ARMOUR')
        ScaleformMovieMethodAddParamInt(0)
        EndScaleformMovieMethod()
        SetScaleformMovieAsNoLongerNeeded(scaleform)
    end
    if Config.CustomPlacement then
        SetMinimapComponentPosition('minimap','L','B',-0.0045,0.002,0.150,0.188888)
        SetMinimapComponentPosition('minimap_mask','L','B',0.020,0.032,0.111,0.159)
        SetMinimapComponentPosition('minimap_blur','L','B',-0.030,0.022,0.266,0.237)
    end
    DisplayRadar(true)
end)
