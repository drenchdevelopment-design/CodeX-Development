(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const clamp = (n,min,max) => Math.max(min,Math.min(max,Number(n)||0));
  const text = value => typeof value === 'string' ? value : '';
  let allowVitals = true;
  function layout(data) {
    for (const key of ['left','top','width','height']) if (!Number.isFinite(data[key])) return;
    if (data.width <= 0 || data.height <= 0) return;
    Object.assign($('navigation').style, {left:`${data.left*100}%`,top:`${data.top*100}%`,width:`${data.width*100}%`,height:`${data.height*100}%`});
    if (/^#[a-f0-9]{6}$/i.test(data.accent||'')) document.documentElement.style.setProperty('--accent',data.accent);
    allowVitals = data.vitals !== false;
    $('vitals').hidden = !allowVitals;
  }
  function update(data) {
    $('navigation').hidden = data.visible !== true;
    if (!data.visible) return;
    $('street').textContent = text(data.street) || 'Unknown road';
    $('district').textContent = text(data.district) || 'City streets';
    $('compass').textContent = ['N','NE','E','SE','S','SW','W','NW'].includes(data.compass) ? data.compass : 'N';
    $('heading').textContent = `${String(Math.round(clamp(data.heading,0,359))).padStart(3,'0')}°`;
    $('speed').textContent = String(Math.round(clamp(data.speed,0,999))).padStart(3,'0');
    $('unit').textContent = data.unit === 'KM/H' ? 'KM/H' : 'MPH';
    $('speed-group').hidden = !data.vehicle;
    $('walking').hidden = !!data.vehicle;
    $('mode').textContent = data.waypoint ? 'ROUTE ACTIVE' : 'FREE ROAM';
    $('mode').classList.toggle('active',!!data.waypoint);
    const health=clamp(data.health,0,100),armor=clamp(data.armor,0,100);
    $('health-fill').style.width=`${health}%`;
    $('armor-fill').style.width=`${armor}%`;
    document.querySelector('.health').classList.toggle('low',health<25);
    document.querySelector('.health').setAttribute('aria-label',`Health ${Math.round(health)} percent`);
    document.querySelector('.armor').setAttribute('aria-label',`Armor ${Math.round(armor)} percent`);
    $('vitals').hidden=!allowVitals;
  }
  window.addEventListener('message',({data})=>{
    if(!data||typeof data!=='object')return;
    if(data.action==='layout')layout(data);
    if(data.action==='update')update(data);
  });
  if(typeof GetParentResourceName==='function'){
    fetch(`https://${GetParentResourceName()}/ready`,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}).catch(()=>{});
  }
})();
