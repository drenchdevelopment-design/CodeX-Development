Config = {}
-- This resource streams your original custom city map. It does not replace the map geometry.
Config.ShowOnFoot = true
Config.SpeedUnit = 'mph' -- 'mph' or 'kmh'
Config.ShowVitals = true
Config.UpdateInterval = 150 -- milliseconds; no NUI focus or keyboard capture
-- Set false only when using the stock radar position. Disable competing radar layouts.
Config.CustomPlacement = true
Config.Placement = { x = 0.015, y = -0.075, width = 0.160, height = 0.185 }
Config.Accent = '#83dfc5'
