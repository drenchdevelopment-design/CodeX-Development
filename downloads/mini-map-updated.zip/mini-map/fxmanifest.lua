fx_version 'cerulean'
game 'gta5'
version '2.0.0'
description 'Unbranded city minimap with clean navigation and status information'
client_scripts { 'config.lua', 'client.lua' }
ui_page 'web/index.html'
files { 'web/index.html', 'web/style.css', 'web/app.js' }
