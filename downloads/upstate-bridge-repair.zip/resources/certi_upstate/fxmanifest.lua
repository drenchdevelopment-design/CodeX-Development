fx_version 'cerulean'
game 'gta5'
this_is_a_map 'yes'
author 'Custom Upstate extension'
description 'Upstate district with compiled geometry, collision and relocated supplied buildings'
version '1.1.0'
files { 'stream/certi_upstate.ytyp' }
data_file 'DLC_ITYP_REQUEST' 'stream/certi_upstate.ytyp'
