# Landmark artwork

The `illustrations/` directory contains detailed miniature landmark images generated for this map edition, with transparent backgrounds. These are original generated illustrations, not assets extracted from the reference screenshot or another map pack.

`cartography.py` composites them into the included circular marker artwork at build time. The procedural drawings in that script remain as a fallback. All terrain and road processing uses code on the supplied source map; the source geography was not passed through image generation.
